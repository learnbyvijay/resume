import React from 'react'


import * as AiIcons from 'react-icons/ai';

export const SidebarData =[
	{
		title:"home",
		path:"/",
		icon:<AiIcons.AiFillHome />,
		cName:'nav-text'
	},
	{
		title:"CreateResume",
		path:"/CreateResume",
		icon:<AiIcons.AiFillHome />,
		cName:'nav-text'
	},
	{
		title:"Contact",
		path:"/Contact",
		icon:<AiIcons.AiFillHome />,
		cName:'nav-text'
	},
	{
		title:"Resume-Pdf",
		path:"/Resumepdf",
		icon:<AiIcons.AiFillHome />,
		cName:'nav-text'
	}


]