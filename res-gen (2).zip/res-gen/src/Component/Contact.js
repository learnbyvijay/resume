import React from 'react'

function Contact(){
	return(
		<div className="conp">
				<div className="content1">
				<div className="heading">
					<h2>Contact-us</h2>
					<p>This organization work on a solving your problem plz contact our admin.</p>
				</div>
				<div className="work">
					<div className="workbox">
						<img src="images/pic.jpg" width="150px" height="150px" />
					</div>
					
						<p>Email:-vijaykasundra99@gmail.com</p>
						<p>Mobile:-8758153670</p>
						
				
				</div>
				
				<br/>
				</div>

		</div>
	);

}
export default Contact;